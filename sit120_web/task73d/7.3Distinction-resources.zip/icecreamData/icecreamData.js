const icecreamSalesListJSON = {
    icecreams: [
        { name: "Vanilla", bestState: 'VIC', totalSold: 78923 },
        { name: "Chocolate", bestState: 'SA', totalSold: 23001 },
        { name: "Cookies 'n Cream", bestState: 'NT', totalSold: 43010 },
        { name: "Strawberry", bestState: 'VIC', totalSold: 29221 },
        { name: "Chocolate Chip", bestState: 'WA', totalSold: 62133 },
        { name: "Mint Chocolate Chip", bestState: 'TAS', totalSold: 12075 },
        { name: "Chocolate Chip Cookie Dough", bestState: 'NSW', totalSold: 39992 },
        { name: "Butter Pecan", bestState: 'ACT', totalSold: 45000 },
        { name: "Birthday Cake", bestState: 'QLD', totalSold: 3001 },
        { name: "Moose Tracks", bestState: 'WA', totalSold: 59004 }
    ]
};
